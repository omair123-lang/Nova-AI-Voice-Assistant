package com.example.voiceassistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.text.Normalizer

/** Fixed-keyword commands (works without internet / AI). */
class CommandHandler(private val ctx: Context, private val executor: ActionExecutor) {

    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val camera = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private var failMessage: String? = null

    private fun n(s: String) = Normalizer.normalize(s, Normalizer.Form.NFC)
    private fun words(vararg w: String) = w.map { n(it) }

    private val aliases = mapOf(
        "यूट्यूब" to "youtube", "युटुब" to "youtube", "यूटूब" to "youtube", "युट्यूब" to "youtube",
        "यूटयूब" to "youtube", "यूट्युब" to "youtube",
        "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "वाट्सएप" to "whatsapp",
        "वाट्सऐप" to "whatsapp", "वॉट्सऐप" to "whatsapp", "वॉट्सएप" to "whatsapp", "वट्सएप" to "whatsapp",
        "कैमरा" to "camera", "क्रोम" to "chrome", "सेटिंग" to "settings",
        "गूगल" to "google", "मैप" to "maps", "गैलरी" to "gallery", "फोटो" to "photos",
        "इंस्टाग्राम" to "instagram", "इंस्टा" to "instagram", "इंस्टाग्राम" to "instagram",
        "फेसबुक" to "facebook", "टेलीग्राम" to "telegram",
        "कैलकुलेटर" to "calculator", "कैलेंडर" to "calendar", "जीमेल" to "gmail",
        "प्लेस्टोर" to "play store", "घड़ी" to "clock", "मैसेज" to "messages", "फोन" to "phone"
    ).mapKeys { n(it.key) }

    private val volumeWords = words(
        "volume", "वॉल्यूम", "वोल्यूम", "वाल्यूम", "वॉलयूम", "वॉल्युम", "आवाज", "awaaz", "awaz", "sound", "साउंड", "सांउड"
    )
    private val upWords = words(
        "badha", "बढ़ा", "बढा", "ज़्यादा", "ज्यादा", "zyada", "jyada", "increase", "तेज", "tez", "loud", "up", "अप"
    )
    private val downWords = words(
        "kam", "kum", "कम", "कुम", "ghata", "घटा", "decrease", "down", "डाउन", "धीमा", "dheema", "slow"
    )
    private val torchWords = words("torch", "flashlight", "flash", "टॉर्च", "टार्च", "टोर्च", "फ्लैश", "फ़्लैश")
    private val offWords = words("off", "band", "बंद", "बन्द", "ऑफ", "ओफ", "ऑफ़", "बुझा", "bujha", "stop")
    private val callWords = words("call", "कॉल", "कोल", "काल")
    private val openWords = words(
        "kholo", "open", "खोलो", "खोलिए", "खोल", "ओपन", "ओपेन", "चलाओ", "चला", "शुरू", "शुरु",
        "चालू", "चालु", "लगाओ", "on", "ऑन", "start", "स्टार्ट"
    )
    private val fillers = words(
        "karo", "करो", "kar", "कर", "do", "दो", "please", "plz", "प्लीज", "app", "ऐप", "एप", "एप्प", "ko", "को", "mein", "में"
    )

    // new command word lists
    private val backWords = words("back", "बैक", "पीछे", "pichhe", "piche", "वापस", "wapas", "vapas")
    private val homeWords = words("home", "होम")
    private val notifWords = words(
        "notification", "notifications", "नोटिफिकेशन", "नोटिफ़िकेशन", "नॉटिफिकेशन", "नोटिफिकेशंस"
    )
    private val screenshotWords = words(
        "screenshot", "screen shot", "स्क्रीनशॉट", "स्क्रीन शॉट", "स्क्रीनशाट", "स्क्रीन शाट", "स्क्रीनशोट"
    )
    private val scrollWords = words("scroll", "स्क्रॉल", "स्क्रोल", "scrol")
    private val scrollUpWords = words("up", "ऊपर", "upar", "oopar")
    private val brightnessWords = words(
        "brightness", "ब्राइटनेस", "ब्राइटनस", "ब्राइट नेस", "brightnes", "रोशनी", "roshni"
    )
    private val alarmWords = words("alarm", "अलार्म", "अलारम")
    private val youtubeWords = words(
        "youtube", "you tube", "यूट्यूब", "यू ट्यूब", "युटुब", "यूटूब", "युट्यूब", "यूटयूब", "यूट्युब"
    )
    private val playWords = words(
        "lagao", "laga", "chalao", "chala", "play", "search", "dhundo", "bajao", "dikhao",
        "लगाओ", "लगा", "चलाओ", "चला", "प्ले", "सर्च", "बजाओ", "बजा", "ढूंढो", "दिखाओ"
    )
    private val ytStop = words("mein", "में", "मैं", "me", "par", "पर", "pe", "पे", "per", "ka", "का", "ki", "की", "ke", "के")
    private val callStop = words(
        "call", "कॉल", "कोल", "काल", "phone", "फोन", "lagao", "laga", "लगाओ", "लगा", "karna", "करना",
        "mujhe", "मुझे", "se", "से", "ji", "जी", "please", "plz", "प्लीज", "karo", "करो", "kar", "कर",
        "do", "दो", "ko", "को"
    )

    // alarm time words
    private val bajeWords = words("baje", "बजे", "bje")
    private val sadeWords = words("sade", "साढ़े", "साढे", "साड़े")
    private val pmWords = words("shaam", "शाम", "raat", "रात", "dopahar", "दोपहर", "pm")
    private val amWords = words("subah", "सुबह", "am")
    private val numWords = mapOf(
        "ek" to 1, "एक" to 1, "do" to 2, "दो" to 2, "teen" to 3, "तीन" to 3,
        "char" to 4, "chaar" to 4, "चार" to 4, "paanch" to 5, "panch" to 5, "पांच" to 5, "पाँच" to 5,
        "chhe" to 6, "che" to 6, "छह" to 6, "छे" to 6, "छः" to 6, "saat" to 7, "सात" to 7,
        "aath" to 8, "आठ" to 8, "nau" to 9, "नौ" to 9, "das" to 10, "दस" to 10,
        "gyarah" to 11, "ग्यारह" to 11, "barah" to 12, "बारह" to 12
    ).mapKeys { n(it.key) }

    /** Tries every guess the speech engine gave; first one that matches a command wins. */
    fun handle(candidates: List<String>): String {
        failMessage = null
        for (c in candidates) {
            val reply = run(c)
            if (reply != null) return reply
        }
        return failMessage ?: "Ye command abhi nahi aata: ${candidates.firstOrNull() ?: ""}"
    }

    private fun run(raw: String): String? {
        val t = n(raw.lowercase().trim())
        val tokens = t.split(Regex("[^\\p{L}\\p{M}\\p{N}]+")).filter { it.isNotEmpty() }

        return when {
            // Torch (first, because "on"/"off" words are also used elsewhere)
            has(t, tokens, torchWords) -> {
                val on = !has(t, tokens, offWords)
                if (setTorch(on)) (if (on) "Torch on kar di" else "Torch off kar di")
                else "Torch control nahi ho paya"
            }

            // Phone-control commands (need Accessibility)
            has(t, tokens, screenshotWords) -> sys("screenshot", "Screenshot le raha hoon")
            has(t, tokens, notifWords) -> sys("notifications", "Notifications khol raha hoon")
            has(t, tokens, scrollWords) ->
                if (has(t, tokens, scrollUpWords)) sys("scroll_up", "Upar scroll kar raha hoon")
                else sys("scroll_down", "Neeche scroll kar raha hoon")

            // Brightness
            has(t, tokens, brightnessWords) -> brightness(t, tokens)

            // Volume
            has(t, tokens, volumeWords) && has(t, tokens, upWords) -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
                "Volume badha diya"
            }
            has(t, tokens, volumeWords) && has(t, tokens, downWords) -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
                "Volume kam kar diya"
            }

            // Alarm, YouTube search
            has(t, tokens, alarmWords) -> alarm(t, tokens)
            has(t, tokens, youtubeWords) && has(t, tokens, playWords) -> youtubeSearch(t)

            // Home / Back
            has(t, tokens, homeWords) -> sys("home", "Home par ja raha hoon")
            has(t, tokens, backWords) -> sys("back", "Peeche ja raha hoon")

            // Call
            has(t, tokens, callWords) -> call(t, tokens)

            // Open app
            has(t, tokens, openWords) -> openApp(tokens)

            else -> null
        }
    }

    // ---------- command helpers ----------

    private fun sys(action: String, okReply: String): String {
        if (VoiceAccessibilityService.instance == null) {
            return "Accessibility on nahi hai. App mein Accessibility button dabake on karo."
        }
        executor.run(listOf(JSONObject().put("type", "system").put("action", action))) {}
        return okReply
    }

    private fun brightness(t: String, tokens: List<String>): String {
        val up = has(t, tokens, upWords)
        val down = has(t, tokens, downWords)
        if (!up && !down) return "Brightness badhani hai ya kam karni hai?"
        if (!executor.brightnessReady()) {
            return "Brightness ke liye Modify system settings ki permission do, phir dobara bolo."
        }
        executor.run(
            listOf(JSONObject().put("type", "brightness").put("direction", if (up) "up" else "down"))
        ) {}
        return if (up) "Brightness badha di" else "Brightness kam kar di"
    }

    private fun alarm(t: String, tokens: List<String>): String {
        val time = parseTime(t, tokens)
        if (time == null) {
            executor.run(listOf(JSONObject().put("type", "alarm_ui"))) {}
            return "Alarm ka time batao, jaise: alarm 7 baje lagao. Alarm screen khol di hai."
        }
        executor.run(
            listOf(
                JSONObject().put("type", "alarm")
                    .put("hour", time.first).put("minute", time.second).put("label", "Alarm")
            )
        ) {}
        return "Alarm laga diya: " + String.format("%02d:%02d", time.first, time.second)
    }

    private fun parseTime(t: String, tokens: List<String>): Pair<Int, Int>? {
        var hour = -1
        var minute = 0
        val m = Regex("(\\d{1,2})\\s*[:.]\\s*(\\d{2})").find(t)
        if (m != null) {
            hour = m.groupValues[1].toInt()
            minute = m.groupValues[2].toInt()
        } else {
            for ((i, tok) in tokens.withIndex()) {
                val next = tokens.getOrNull(i + 1)
                val num = tok.toIntOrNull() ?: if (next != null && next in bajeWords) numWords[tok] else null
                if (num != null) {
                    hour = num
                    break
                }
            }
            if (hour >= 0 && has(t, tokens, sadeWords)) minute = 30
        }
        if (hour < 0 || hour > 23 || minute > 59) return null
        if (hour in 1..11 && has(t, tokens, pmWords)) hour += 12
        if (hour == 12 && has(t, tokens, amWords)) hour = 0
        return hour to minute
    }

    private fun youtubeSearch(t: String): String {
        var text = t
        youtubeWords.forEach { text = text.replace(it, " ") }
        val skip = (playWords + fillers + ytStop).toSet()
        val query = text.split(Regex("[^\\p{L}\\p{M}\\p{N}]+"))
            .filter { it.isNotEmpty() && it !in skip }
            .joinToString(" ")
        return if (query.isEmpty()) {
            executor.run(listOf(JSONObject().put("type", "open_app").put("app", "youtube"))) {}
            "YouTube khol raha hoon"
        } else {
            executor.run(listOf(JSONObject().put("type", "youtube_search").put("query", query))) {}
            "YouTube par $query chala raha hoon"
        }
    }

    private fun call(t: String, tokens: List<String>): String {
        val digits = t.filter { it.isDigit() }
        if (digits.length >= 5) {
            executor.run(listOf(JSONObject().put("type", "call").put("number", digits))) {}
            return "$digits par call laga raha hoon"
        }
        val skip = callStop.toSet()
        val name = tokens.filter { it !in skip }.joinToString(" ")
        if (name.isEmpty()) {
            ctx.startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return "Kisko call karna hai? Dialer khol diya."
        }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return "Contacts ki permission do (Settings, Apps, Voice Assistant, Permissions)."
        }
        val c = executor.findContact(name) ?: return "\"$name\" naam ka contact nahi mila"
        executor.run(listOf(JSONObject().put("type", "call").put("number", c.second))) {}
        return "${c.first} ko call laga raha hoon"
    }

    private fun openApp(tokens: List<String>): String? {
        val skip = (openWords + fillers).toSet()
        var name = tokens.filter { it !in skip }.joinToString(" ")
        val compact = name.replace(" ", "")
        aliases.entries.firstOrNull { compact.contains(it.key) }?.let { name = it.value }
        name = name.trim()
        if (name.isEmpty()) {
            failMessage = "Kaun sa app kholna hai?"
            return null
        }

        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launcher, 0).firstOrNull {
            val label = it.loadLabel(pm).toString().lowercase()
            label.contains(name) || label.replace(" ", "").contains(name.replace(" ", ""))
        }
        if (match == null) {
            failMessage = "\"$name\" naam ka app nahi mila"
            return null
        }

        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
        if (intent == null) {
            failMessage = "App khul nahi paya"
            return null
        }
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "${match.loadLabel(pm)} khol diya"
    }

    private fun setTorch(on: Boolean): Boolean = try {
        camera.setTorchMode(camera.cameraIdList.first(), on)
        true
    } catch (e: Exception) {
        false
    }

    // Short English words must match a whole word ("on" must not match inside "kon"); the rest can match anywhere
    private fun has(text: String, tokens: List<String>, list: List<String>) = list.any { w ->
        if (w.length <= 3 && w.all { it.code < 128 }) w in tokens else text.contains(w)
    }
}
