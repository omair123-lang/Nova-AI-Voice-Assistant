package com.example.voiceassistant

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Talks to the Gemini API. If one model fails (not available / busy), it tries the next one. */
object GeminiClient {
    const val DEFAULT_MODEL = "gemini-3.5-flash-lite"
    private val fallbackModels = listOf("gemini-3.8-flash", "gemini-3.1-flash-lite")
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"

    class AiException(message: String, val fatal: Boolean = false) : Exception(message)

    fun ask(apiKey: String, model: String, system: String, user: String): String {
        var last = "AI ne jawab nahi diya"
        for (m in (listOf(model) + fallbackModels).distinct()) {
            try {
                return call(apiKey, m, system, user)
            } catch (e: AiException) {
                if (e.fatal) throw e
                last = e.message ?: last
            }
        }
        throw AiException(last)
    }

    private fun call(apiKey: String, model: String, system: String, user: String): String {
        val conn = URL(BASE + model + ":generateContent").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 8000
            conn.readTimeout = 25000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("x-goog-api-key", apiKey)

            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
                .put("contents", JSONArray().put(
                    JSONObject().put("role", "user")
                        .put("parts", JSONArray().put(JSONObject().put("text", user)))
                ))
                .put("generationConfig", JSONObject()
                    .put("responseMimeType", "application/json")
                    .put("temperature", 0.2)
                    .put("maxOutputTokens", 1024))
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()

            if (code in 200..299) return extractText(text)
            throw errorFor(code, text)
        } catch (e: IOException) {
            throw AiException("Internet nahi chal raha", fatal = true)
        } finally {
            conn.disconnect()
        }
    }

    private fun errorFor(code: Int, text: String): AiException = when {
        code == 400 && (text.contains("API key") || text.contains("API_KEY")) ->
            AiException("API key galat hai", fatal = true)
        code == 401 || code == 403 -> AiException("API key ya permission mein dikkat hai", fatal = true)
        code == 429 -> AiException("Free limit khatam, thodi der baad try karo")
        else -> AiException("AI server error ($code)")
    }

    private fun extractText(json: String): String {
        try {
            val parts = JSONObject(json).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (!p.optBoolean("thought", false)) sb.append(p.optString("text"))
            }
            if (sb.isBlank()) throw AiException("AI ka jawab khali tha")
            return sb.toString()
        } catch (e: JSONException) {
            throw AiException("AI ka jawab samajh nahi aaya")
        }
    }
}
