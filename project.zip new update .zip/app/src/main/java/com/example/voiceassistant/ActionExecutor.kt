package com.example.voiceassistant

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.content.ContextCompat
import org.json.JSONObject

/** Runs the actions that the AI decided on. */
class ActionExecutor(private val ctx: Context) {

    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val camera = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val main = Handler(Looper.getMainLooper())

    private val launchTypes = setOf("open_app", "youtube_search", "web_search", "navigate", "call")

    /** Runs actions one by one (with a small wait after launching an app). Calls onDone with a list of problems. */
    fun run(actions: List<JSONObject>, onDone: (List<String>) -> Unit) {
        val problems = mutableListOf<String>()
        fun step(i: Int) {
            if (i >= actions.size) {
                onDone(problems)
                return
            }
            val a = actions[i]
            val err = try {
                runOne(a)
            } catch (e: Exception) {
                "${a.optString("type")} nahi chal paya"
            }
            if (err != null) problems += err
            val wait = if (a.optString("type") in launchTypes) 1800L else 350L
            main.postDelayed({ step(i + 1) }, wait)
        }
        step(0)
    }

    private fun runOne(a: JSONObject): String? = when (a.optString("type")) {
        "open_app" -> openApp(a.optString("app"))
        "torch" -> if (setTorch(a.optBoolean("on", true))) null else "torch control nahi ho paya"
        "volume" -> volume(a)
        "call" -> call(a)
        "alarm" -> alarm(a)
        "alarm_ui" -> launch(Intent(AlarmClock.ACTION_SHOW_ALARMS))
        "brightness" -> brightness(a)
        "timer" -> timer(a)
        "youtube_search" -> launch(view("https://www.youtube.com/results?search_query=" + Uri.encode(a.optString("query"))))
        "web_search" -> launch(view("https://www.google.com/search?q=" + Uri.encode(a.optString("query"))))
        "navigate" -> navigate(a.optString("destination"))
        "system" -> system(a.optString("action"))
        "click_text" -> accessibility { it.clickText(a.optString("text")) }
        "type_text" -> accessibility { it.typeText(a.optString("text")) }
        else -> "ye kaam abhi support nahi hai"
    }

    private fun view(url: String) = Intent(Intent.ACTION_VIEW, Uri.parse(url))

    private fun launch(intent: Intent): String? = try {
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        null
    } catch (e: ActivityNotFoundException) {
        "is kaam ke liye app nahi mila"
    }

    private fun openApp(name: String): String? {
        val q = name.trim().lowercase()
        if (q.isEmpty()) return "app ka naam samajh nahi aaya"
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        fun label(r: ResolveInfo) = r.loadLabel(pm).toString().lowercase()
        val match = apps.firstOrNull { label(it) == q }
            ?: apps.firstOrNull { label(it).startsWith(q) }
            ?: apps.firstOrNull { label(it).contains(q) }
            ?: apps.firstOrNull { label(it).replace(" ", "").contains(q.replace(" ", "")) }
            ?: return "$name naam ka app nahi mila"
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "$name khul nahi paya"
        return launch(intent)
    }

    private fun setTorch(on: Boolean): Boolean = try {
        camera.setTorchMode(camera.cameraIdList.first(), on)
        true
    } catch (e: Exception) {
        false
    }

    private fun volume(a: JSONObject): String? {
        val stream = AudioManager.STREAM_MUSIC
        val max = audio.getStreamMaxVolume(stream)
        if (a.has("percent")) {
            val p = a.optInt("percent").coerceIn(0, 100)
            audio.setStreamVolume(stream, p * max / 100, AudioManager.FLAG_SHOW_UI)
            return null
        }
        when (a.optString("direction")) {
            "up" -> repeat(3) {
                audio.adjustStreamVolume(stream, AudioManager.ADJUST_RAISE, if (it == 2) AudioManager.FLAG_SHOW_UI else 0)
            }
            "down" -> repeat(3) {
                audio.adjustStreamVolume(stream, AudioManager.ADJUST_LOWER, if (it == 2) AudioManager.FLAG_SHOW_UI else 0)
            }
            "mute" -> audio.setStreamVolume(stream, 0, AudioManager.FLAG_SHOW_UI)
            "max" -> audio.setStreamVolume(stream, max, AudioManager.FLAG_SHOW_UI)
            else -> return "volume ka kaam samajh nahi aaya"
        }
        return null
    }

    private fun call(a: JSONObject): String? {
        var number = a.optString("number").filter { it.isDigit() || it == '+' }
        if (number.isEmpty()) {
            val name = a.optString("name")
            if (name.isBlank()) return "kisko call karna hai?"
            number = findNumber(name) ?: return "$name naam ka contact nahi mila"
        }
        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE) ==
            PackageManager.PERMISSION_GRANTED
        val action = if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL
        return launch(Intent(action, Uri.fromParts("tel", number, null)))
    }

    private fun findNumber(name: String): String? = findContact(name)?.second

    /** Finds the best matching contact. Returns (display name, number) or null. */
    fun findContact(query: String): Pair<String, String>? {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) !=
            PackageManager.PERMISSION_GRANTED
        ) return null
        val q = query.trim().lowercase()
        if (q.isEmpty()) return null
        val qSkel = NameMatch.skeleton(q)
        var best: Pair<String, String>? = null
        var bestScore = 0
        val phone = ContactsContract.CommonDataKinds.Phone
        ctx.contentResolver.query(
            phone.CONTENT_URI, arrayOf(phone.DISPLAY_NAME, phone.NUMBER), null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: continue
                val number = c.getString(1) ?: continue
                val low = name.lowercase()
                val skel = NameMatch.skeleton(low)
                val tokenSkels = low.split(" ").map { NameMatch.skeleton(it) }
                val score = when {
                    low == q -> 100
                    qSkel.isNotEmpty() && skel == qSkel -> 90
                    qSkel.isNotEmpty() && tokenSkels.any { it == qSkel } -> 80
                    low.contains(q) -> 70
                    qSkel.length >= 2 && skel.startsWith(qSkel) -> 60
                    qSkel.length >= 2 && skel.contains(qSkel) -> 40
                    else -> 0
                }
                if (score > bestScore) {
                    bestScore = score
                    best = name to number
                }
            }
        }
        return best
    }

    /** True if we may change brightness; otherwise opens the permission screen. */
    fun brightnessReady(): Boolean {
        if (Settings.System.canWrite(ctx)) return true
        launch(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)))
        return false
    }

    private fun brightness(a: JSONObject): String? {
        if (!Settings.System.canWrite(ctx)) return "brightness ki permission nahi hai"
        val cr = ctx.contentResolver
        val cur = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
        val next = when (a.optString("direction")) {
            "up" -> cur + 50
            "down" -> cur - 50
            "max" -> 255
            "min" -> 10
            else -> cur
        }.coerceIn(10, 255)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, next)
        return null
    }

    private fun alarm(a: JSONObject): String? {
        if (!a.has("hour")) return "alarm ka time samajh nahi aaya"
        val intent = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour"))
            .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute", 0))
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Alarm"))
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return launch(intent)
    }

    private fun timer(a: JSONObject): String? {
        val sec = a.optInt("seconds", 0)
        if (sec <= 0) return "timer ka time samajh nahi aaya"
        val intent = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, sec)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        return launch(intent)
    }

    private fun navigate(dest: String): String? {
        if (dest.isBlank()) return "kahan jana hai?"
        val first = launch(view("google.navigation:q=" + Uri.encode(dest)))
        return if (first == null) null else launch(view("geo:0,0?q=" + Uri.encode(dest)))
    }

    private fun system(action: String): String? =
        accessibility { it.system(action) }

    private fun accessibility(block: (VoiceAccessibilityService) -> Boolean): String? {
        val svc = VoiceAccessibilityService.instance
            ?: return "Accessibility service on nahi hai"
        return if (block(svc)) null else "screen par ye kaam nahi ho paya"
    }
}
