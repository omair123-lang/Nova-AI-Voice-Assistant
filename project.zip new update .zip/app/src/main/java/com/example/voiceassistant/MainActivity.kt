package com.example.voiceassistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var recognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech
    private lateinit var offline: CommandHandler
    private lateinit var actions: ActionExecutor
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var continuous: SwitchCompat
    private lateinit var accessBtn: Button

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("va", MODE_PRIVATE) }

    private var ttsReady = false
    private var busy = false
    private var warnedNoKey = true
    private var pending: List<JSONObject>? = null

    private val yesWords = listOf(
        "haan", "han", "haa", "ha", "yes", "yeah", "ok", "okay", "kardo", "kar do", "thik", "theek", "sure",
        "हाँ", "हां", "हा", "ठीक", "कर दो", "करदो", "जी", "येस", "ओके"
    )
    private val noWords = listOf(
        "nahi", "nahin", "nhi", "no", "mat", "cancel", "ruko", "ruk", "stop",
        "नहीं", "नही", "मत", "रुको", "रुक", "कैंसिल", "नो"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        log = findViewById(R.id.log)
        logScroll = findViewById(R.id.logScroll)
        continuous = findViewById(R.id.continuous)
        accessBtn = findViewById(R.id.accessBtn)

        actions = ActionExecutor(applicationContext)
        offline = CommandHandler(this, actions)
        tts = TextToSpeech(this, this)

        askPermissions()
        setupRecognizer()

        findViewById<Button>(R.id.micButton).setOnClickListener { listen() }
        findViewById<Button>(R.id.settingsBtn).setOnClickListener { showSettings() }
        accessBtn.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        continuous.setOnCheckedChangeListener { _, on ->
            if (on) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                listen()
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        accessBtn.text = if (VoiceAccessibilityService.instance != null)
            "Accessibility: ON ✔" else "Accessibility: OFF"
    }

    // ---------- permissions ----------

    private fun askPermissions() {
        val needed = listOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        ).filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (needed.isNotEmpty()) ActivityCompat.requestPermissions(this, needed.toTypedArray(), 1)
    }

    // ---------- listening ----------

    private fun setupRecognizer() {
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val list = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.filter { it.isNotBlank() }
                if (list.isNullOrEmpty()) return
                handleSpeech(list)
            }

            override fun onError(error: Int) {
                val quiet = error == SpeechRecognizer.ERROR_NO_MATCH ||
                    error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                status.text = if (quiet) "Kuch sunai nahi diya" else "Mic error ($error)"
                if (quiet && continuous.isChecked) {
                    main.postDelayed({ if (continuous.isChecked) listen() }, 800)
                }
            }

            override fun onReadyForSpeech(params: Bundle?) { status.text = "Sun raha hoon..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun listen() {
        if (busy) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            status.text = "Mic permission do"
            return
        }
        tts.stop()
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        }
        status.text = "Sun raha hoon..."
        recognizer.startListening(intent)
    }

    // ---------- understanding ----------

    private fun handleSpeech(list: List<String>) {
        addLog("Tum: ${list.first()}")

        val p = pending
        if (p != null) {
            pending = null
            when (yesNo(list)) {
                true -> {
                    status.text = "Ho raha hai..."
                    busy = true
                    runActions(p, "Theek hai.")
                    return
                }
                false -> {
                    say("Theek hai, cancel kar diya.")
                    return
                }
                null -> {} // something new: treat as a fresh command
            }
        }
        process(list)
    }

    private fun yesNo(list: List<String>): Boolean? {
        val t = list.joinToString(" ").lowercase()
        val tokens = t.split(Regex("[^\\p{L}\\p{M}]+"))
        fun hit(words: List<String>) = words.any { if (it.contains(" ")) t.contains(it) else it in tokens }
        return when {
            hit(noWords) -> false
            hit(yesWords) -> true
            else -> null
        }
    }

    private fun process(list: List<String>) {
        val key = prefs.getString("key", "").orEmpty().trim()
        if (key.isEmpty()) {
            val r = offline.handle(list)
            val hint = if (!warnedNoKey) {
                warnedNoKey = true
                " Smart AI ke liye Settings mein API key daalo."
            } else ""
            say(r + hint)
            return
        }

        status.text = "Soch raha hoon..."
        busy = true
        val model = prefs.getString("model", "").orEmpty().trim().ifEmpty { GeminiClient.DEFAULT_MODEL }
        worker.execute {
            try {
                val raw = GeminiClient.ask(key, model, Brain.systemPrompt(), Brain.userMessage(list))
                val plan = Brain.parse(raw)
                main.post { onPlan(plan) }
            } catch (e: Exception) {
                val why = (e as? GeminiClient.AiException)?.message ?: "AI se connect nahi hua"
                main.post {
                    val r = offline.handle(list)
                    say("$r ($why)")
                }
            }
        }
    }

    private fun onPlan(plan: Plan) {
        when {
            plan.confirm && plan.actions.isNotEmpty() -> {
                pending = plan.actions
                say(plan.reply.ifBlank { "Pakka kar doon?" })
            }
            plan.actions.isEmpty() ->
                say(plan.reply.ifBlank { "Samajh nahi aaya, dobara bolo." })
            else -> runActions(plan.actions, plan.reply)
        }
    }

    private fun runActions(list: List<JSONObject>, reply: String) {
        actions.run(list) { problems ->
            val text = if (problems.isEmpty()) reply
            else (reply + " Par " + problems.joinToString(", ") + ".").trim()
            say(text)
        }
    }

    // ---------- speaking ----------

    private fun say(text: String) {
        busy = false
        addLog("Assistant: $text")
        status.text = text
        if (ttsReady && text.isNotBlank()) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "reply")
        } else {
            afterSpeech()
        }
    }

    private fun afterSpeech() {
        if (continuous.isChecked || pending != null) {
            main.postDelayed({ if (continuous.isChecked || pending != null) listen() }, 500)
        }
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) {
            tts.language = Locale("en", "IN")
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { main.post { afterSpeech() } }
                override fun onError(utteranceId: String?) { main.post { afterSpeech() } }
            })
            ttsReady = true
        }
    }

    private fun addLog(line: String) {
        log.append(line + "\n\n")
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    // ---------- settings ----------

    private fun showSettings() {
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, 0)
        }
        val keyBox = EditText(this).apply {
            hint = "Gemini API key"
            setText(prefs.getString("key", ""))
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        val modelBox = EditText(this).apply {
            hint = "Model (khali chhodo: ${GeminiClient.DEFAULT_MODEL})"
            setText(prefs.getString("model", ""))
            inputType = InputType.TYPE_CLASS_TEXT
            setSingleLine(true)
        }
        box.addView(TextView(this).apply { text = "Key aistudio.google.com se free milti hai." })
        box.addView(keyBox)
        box.addView(modelBox)

        AlertDialog.Builder(this)
            .setTitle("AI Settings")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit()
                    .putString("key", keyBox.text.toString().trim())
                    .putString("model", modelBox.text.toString().trim())
                    .apply()
                status.text = "Settings save ho gayi"
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onDestroy() {
        recognizer.destroy()
        tts.shutdown()
        worker.shutdownNow()
        super.onDestroy()
    }
}
