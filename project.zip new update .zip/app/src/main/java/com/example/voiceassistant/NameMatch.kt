package com.example.voiceassistant

/** Turns a name (Hindi or English letters) into a rough sound skeleton so "भैया" matches "Bhaiya". */
object NameMatch {

    private val deva = mapOf(
        '\u0915' to "k", '\u0916' to "k", '\u0917' to "g", '\u0918' to "g", '\u0919' to "n",
        '\u091A' to "c", '\u091B' to "c", '\u091C' to "j", '\u091D' to "j", '\u091E' to "n",
        '\u091F' to "t", '\u0920' to "t", '\u0921' to "d", '\u0922' to "d", '\u0923' to "n",
        '\u0924' to "t", '\u0925' to "t", '\u0926' to "d", '\u0927' to "d", '\u0928' to "n",
        '\u092A' to "p", '\u092B' to "f", '\u092C' to "b", '\u092D' to "b", '\u092E' to "m",
        '\u092F' to "y", '\u0930' to "r", '\u0932' to "l", '\u0935' to "v", '\u0936' to "s",
        '\u0937' to "s", '\u0938' to "s",
        '\u0958' to "k", '\u0959' to "k", '\u095A' to "g", '\u095B' to "j",
        '\u095C' to "d", '\u095D' to "d", '\u095E' to "f", '\u095F' to "y"
    )

    fun skeleton(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase()) {
            val piece: String = deva[ch] ?: when {
                ch in 'a'..'z' -> when (ch) {
                    'a', 'e', 'i', 'o', 'u', 'h' -> ""
                    'w' -> "v"
                    'z' -> "j"
                    'q' -> "k"
                    else -> ch.toString()
                }
                else -> ""
            }
            for (p in piece) {
                if (sb.isEmpty() || sb.last() != p) sb.append(p)
            }
        }
        return sb.toString()
    }
}
