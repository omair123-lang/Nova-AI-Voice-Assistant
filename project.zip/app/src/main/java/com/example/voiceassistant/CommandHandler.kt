package com.example.voiceassistant

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri

class CommandHandler(private val ctx: Context) {

    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val camera = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    // Hindi names -> English app names
    private val aliases = mapOf(
        "यूट्यूब" to "youtube", "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp",
        "कैमरा" to "camera", "क्रोम" to "chrome", "सेटिंग" to "settings",
        "गूगल" to "google", "मैप" to "maps", "गैलरी" to "gallery"
    )

    private val openWords = listOf("kholo", "open", "खोलो", "खोल", "चालू करो ऐप")
    private val upWords = listOf("badhao", "badha", "increase", "up", "बढ़ाओ", "बढ़ा", "ज़्यादा", "ज्यादा")
    private val downWords = listOf("kam", "ghatao", "decrease", "down", "घटाओ", "घटा", "कम")

    fun handle(raw: String): String {
        val t = raw.lowercase().trim()

        return when {
            // Volume
            has(t, "volume", "वॉल्यूम", "आवाज़", "आवाज") && has(t, *upWords.toTypedArray()) -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                "Volume badha diya"
            }
            has(t, "volume", "वॉल्यूम", "आवाज़", "आवाज") && has(t, *downWords.toTypedArray()) -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                "Volume kam kar diya"
            }

            // Flashlight
            has(t, "torch", "flashlight", "टॉर्च", "फ्लैशलाइट") -> {
                val on = !has(t, "band", "off", "बंद")
                setTorch(on)
                if (on) "Torch on" else "Torch off"
            }

            // Call (opens dialer with the number)
            has(t, "call", "कॉल") -> {
                val number = t.filter { it.isDigit() }
                if (number.isEmpty()) {
                    ctx.startActivity(Intent(Intent.ACTION_DIAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    "Dialer khol diya"
                } else {
                    ctx.startActivity(
                        Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                    "$number dial kar raha hoon"
                }
            }

            // Open app
            has(t, *openWords.toTypedArray()) -> openApp(t)

            else -> "Ye command abhi nahi aata: $raw"
        }
    }

    private fun openApp(text: String): String {
        var name = text
        openWords.forEach { name = name.replace(it, "") }
        name = name.replace("ऐप", "").replace("app", "").trim()
        aliases.forEach { (hi, en) -> if (name.contains(hi)) name = en }
        if (name.isEmpty()) return "Kaun sa app kholna hai?"

        val pm = ctx.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launcher, 0).firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(name)
        } ?: return "$name naam ka app nahi mila"

        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "App khul nahi paya"
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "${match.loadLabel(pm)} khol diya"
    }

    private fun setTorch(on: Boolean) {
        val id = camera.cameraIdList.firstOrNull() ?: return
        camera.setTorchMode(id, on)
    }

    private fun has(text: String, vararg words: String) = words.any { text.contains(it) }
}
